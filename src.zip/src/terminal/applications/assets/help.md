



# Help
### EDSH is just like BASH except much more limited.

## • Type*ls* to list directory contents

## • Type*cd* to change directory

## • Type*show* to render .md files

## • Use ↑ and ↓ keys to scroll

### Tip: try typing "show -all"


## All commands
### EDSH, version 0.2.1 

