import Applications from "./applications";

export default Applications;