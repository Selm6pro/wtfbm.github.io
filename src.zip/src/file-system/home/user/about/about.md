



# Hi there

My name is wtfbm, I’m an award-winning web dev / digital designer and full stack software engineer. I have a passion for all things technology and design, from software engineering & machine learning to UI/UX & 3D graphics.

In addition to my love of technology and design, I am also interested in education, history, economics and politics.

Type "cd ~/projects" then "ls" to see details of some of the projects I have developed over my fifteen plus years of coding experience.