!(/images/ed-title.png?aspect=2&noflow=true&width=1.33)


##   Hi there, 

#  *I'm wtfbm*

##   • Software Engineer
##   • Digital Designer





### Welcome to ED-Linux 1.0 LTS
### →→ Scroll or type "help" to get started
