



## Welcome to ED-Linux 1.0 LTS



#  Hi there,
#  *I'm wtfbm*
#  -Creative Developer
##     — Computer Science graduate of
##        the University of Melbourne
##
###   *Scroll* or type "help" to get started
