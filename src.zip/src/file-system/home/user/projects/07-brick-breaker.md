



## *Brick Breaker*
## 2019

### • Software Engineering,
### • Object Oriented Design, GRASP & GoF Patterns
!(/images/brick-breaker.png?aspect=1.3913)
The below screenshot is of a university assignment, where we had to follow a spec and use object oriented design principles and patterns to produce a brick-breaker type game in Java. I finished with time to spare so decided to implement a real time lighting and particle engine from scratch. The engine was capable of handling different lights at different intensities, intersecting shadows and a large number of shadow casting game objects.