



## *Project L*
## 2015

### • Game Dev,
### • Design, 3D
!(/images/project-l.png?aspect=1.7777)
Over the years I have made many games, with the screenshot below representing one of them from around 2015. Probably one of the more technically challenging games I have created, it was an open world sandbox written in Unity, where you could interact, move, rotate and scale the objects in the world to build anything you wanted.