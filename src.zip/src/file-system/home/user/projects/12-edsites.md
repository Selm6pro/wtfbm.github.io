



## *EdSites*
## 2010

### • Design,
### • Web Dev
!(/images/edsites.png?aspect=1.4457)
Below is one of my earliest creations dating back to 2010. As a budding 10 year old web designer I needed a website to showcase my work and attract “clients”, so I made one! I called it EdSites and registered the domain name edsites.biz with my father’s credit card and got to work. All the HTML, CSS and even the JavaScript was written completely by hand by me. The website was such a success that it resulted in some clients albeit they were all my family members.