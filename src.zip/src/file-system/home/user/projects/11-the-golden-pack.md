



## *The Golden Pack*
## 2012-13

### • Design,
### • Illustration
!(/images/the-golden-pack.png?aspect=1.3333)
When I was 12 years old, I played a lot of Minecraft however, I was never very happy with the low resolution look of the game. I decided to remedy this by creating a texture pack, which is a file containing alternative looks or textures for the objects in the game. When I put my work online, after some refinement I received my first 1000 downloads. Spotting a business opportunity, I added ads to the download link. My texture pack was downloaded over 50,000 times, earning me over a few hundred dollars.