



## *Folio (This Website)*
## 2022

### • TypeScript, WebGL,
### • Shader Language, Web Dev
This was a project I built for fun over one of my uni breaks, built in TypeScript and THREE.js, it contains a number of nifty features such as: a 3D retro computer that you can interact with, a very simple UNIX shell implementation, a files system implementation, markdown interpreter and renderer, and a text layout engine.