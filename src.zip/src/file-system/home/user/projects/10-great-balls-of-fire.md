



## *Great Balls of Fire*
## 2013-14

### • Mobile Dev, Design,
### • Illustration, Branding
!(/images/great-balls-of-fire.png?aspect=1.77777)
Great Balls of Fire was a game I made when I was 13 years old and is one of the creations I am most proud of. It was an endless scroller where you played as the titular Ball of Fire, attempting to stay in the sky by jumping on air ships. It was published on the App Store and Play Store and remained there for a number of years (before I got tired of paying Apple's developer fee) and even netted a few thousand downloads.