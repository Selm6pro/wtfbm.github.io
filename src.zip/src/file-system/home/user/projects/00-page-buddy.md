



## *Page Buddy*
## 2023-24

### • React, TypeScript, Gleam (Erlang),
### • Sql, AI, Web Dev
Page Buddy is a word processor, with everything you would expect from WYSIWYG editor along with a novel drag and drop user interface and a powerful style/theme engine. Additionally it provides: rich accessibility tools, including, an embedded neural network (Wasm / WebGPU) for auto complete, developed to help people with dyslexia (like me) with their writing; and the ability for users to publish their documents to the web.

Page Buddy is about 35K lines of code, it even has some users (~100 WAUs)!