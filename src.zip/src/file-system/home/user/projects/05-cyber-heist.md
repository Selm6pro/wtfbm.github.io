



## *Cyber Heist*
## 2020

### • Shader Dev, Design,
### • User Testing, Game Dev
!(/images/cyber-heist.png?aspect=1.8181)
For the subject Graphics and Interaction, I worked in a team to produce a time based endless runner game called CyberHeist. The game was built in Unity/C# and made use of a number of Azure APIs to add online play functionality. I was responsible for most of the online investigation and a large amount of the game logic, shader programming and user testing. CyberHeist received a final mark of over 95% and the trailer can be found below.