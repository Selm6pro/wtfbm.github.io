



## *Glowbal*
## 2020

### • Agile, Design,
### • Accessibility, UI/UX, Web Dev

As part of the university subject IT Project, I was required to produce an ePortfolio web app as part of a small group. We called our app Glowbal and built it with TypeScript, React, Express and employed an agile development process. I was a front end lead and wrote most of the UI components. I was also responsible for accessibility testing and ensuring users of all abilities could access our app.