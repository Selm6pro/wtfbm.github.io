



## *Writing Buddy*
## 2021

### • React, TypeScript, UI/UX, Branding,
### • AI, Deep Learning, Web Dev
!(/images/writing-buddy.png?aspect=1.4457)
An early version of Page Buddy.

I have dyslexia and as such, have always found writing and particularly spelling difficult and tedious. While there are a number of tools on the market designed to aid people with learning difficulties, based on my experience, all fall short in one way or another. To fix this I developed Writing Buddy, a “what you see is what you get” text editor designed to help people write better, faster and with more confidence.