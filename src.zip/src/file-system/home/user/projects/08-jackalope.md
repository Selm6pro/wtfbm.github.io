



## *Jackalope*
## 2017

### • Industrial Design,
### • Visual Communication, Branding
!(/images/jackalope.png?aspect=1.7977)
In my final year of high school I took a subject called Visual Communication Design (VCD). As part of VCD we were given the assignment to develop and fulfill a brief for a fictional client. I gave myself the brief to design a series of smart home appliances for the made up company Jackalope and produce accompanying visual identity and advertising material. Below is a poster of a smart speakers I designed with the Jackalope logo in the corner. See more of this project on Behance.