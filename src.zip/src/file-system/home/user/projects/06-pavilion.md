



## *Pavilion*
## 2019

### • VR, 3D Rendering,
### • Parametric Design, Architecture
!(/images/pavilion.png?aspect=1.7777)
At university, in addition to my computer science subjects, I completed a number of architecture and design electives. In one of my favourite architecture subjects we had to design a pavilion using parametric tools and present it in VR with Unreal Engine. I programmatically modeled a magnetic field and extracted the field lines to inform the structure of my pavilion. I enjoyed this assignment so much I decided to extend myself and produce a number of 3D ray traced renders some of which are below. My design received first class honors and was exhibited in the Melbourne School of Design annual exhibition (MSDx).